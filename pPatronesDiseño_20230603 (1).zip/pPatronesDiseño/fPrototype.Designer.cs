﻿namespace pPatronesDiseño
{
    partial class fPrototype
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRespuesta = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtPensum3 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtDocumento3 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtTipoPrograma3 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPrograma3 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtNombre3 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtPensum2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtDocumento2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTipoPrograma2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPrograma2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNombre2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtPensum1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTipoPrograma1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPrograma1 = new System.Windows.Forms.TextBox();
            this.txtDocumento1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNombre1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnPrototipo = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblRespuesta
            // 
            this.lblRespuesta.AutoSize = true;
            this.lblRespuesta.Location = new System.Drawing.Point(222, 277);
            this.lblRespuesta.Name = "lblRespuesta";
            this.lblRespuesta.Size = new System.Drawing.Size(10, 13);
            this.lblRespuesta.TabIndex = 29;
            this.lblRespuesta.Text = "-";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtPensum3);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.txtDocumento3);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.txtTipoPrograma3);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.txtPrograma3);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.txtNombre3);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Location = new System.Drawing.Point(31, 189);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(888, 72);
            this.groupBox3.TabIndex = 28;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ESTUDIANTE 3";
            // 
            // txtPensum3
            // 
            this.txtPensum3.Location = new System.Drawing.Point(692, 32);
            this.txtPensum3.Name = "txtPensum3";
            this.txtPensum3.Size = new System.Drawing.Size(160, 20);
            this.txtPensum3.TabIndex = 22;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(689, 16);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 13);
            this.label15.TabIndex = 21;
            this.label15.Text = "PENSUM";
            // 
            // txtDocumento3
            // 
            this.txtDocumento3.Location = new System.Drawing.Point(16, 32);
            this.txtDocumento3.Name = "txtDocumento3";
            this.txtDocumento3.Size = new System.Drawing.Size(125, 20);
            this.txtDocumento3.TabIndex = 20;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(13, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 13);
            this.label13.TabIndex = 19;
            this.label13.Text = "DOCUMENTO";
            // 
            // txtTipoPrograma3
            // 
            this.txtTipoPrograma3.Location = new System.Drawing.Point(508, 32);
            this.txtTipoPrograma3.Name = "txtTipoPrograma3";
            this.txtTipoPrograma3.Size = new System.Drawing.Size(160, 20);
            this.txtTipoPrograma3.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(505, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "TIPO PROGRAMA";
            // 
            // txtPrograma3
            // 
            this.txtPrograma3.Location = new System.Drawing.Point(337, 32);
            this.txtPrograma3.Name = "txtPrograma3";
            this.txtPrograma3.Size = new System.Drawing.Size(160, 20);
            this.txtPrograma3.TabIndex = 16;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(334, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 13);
            this.label11.TabIndex = 13;
            this.label11.Text = "PROGRAMA";
            // 
            // txtNombre3
            // 
            this.txtNombre3.Location = new System.Drawing.Point(162, 32);
            this.txtNombre3.Name = "txtNombre3";
            this.txtNombre3.Size = new System.Drawing.Size(160, 20);
            this.txtNombre3.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(159, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "ESTUDIANTE";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtPensum2);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txtDocumento2);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtTipoPrograma2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txtPrograma2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtNombre2);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(31, 99);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(888, 72);
            this.groupBox2.TabIndex = 27;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ESTUDIANTE 2";
            // 
            // txtPensum2
            // 
            this.txtPensum2.Location = new System.Drawing.Point(692, 32);
            this.txtPensum2.Name = "txtPensum2";
            this.txtPensum2.Size = new System.Drawing.Size(160, 20);
            this.txtPensum2.TabIndex = 22;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(689, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 13);
            this.label14.TabIndex = 21;
            this.label14.Text = "PENSUM";
            // 
            // txtDocumento2
            // 
            this.txtDocumento2.Location = new System.Drawing.Point(16, 36);
            this.txtDocumento2.Name = "txtDocumento2";
            this.txtDocumento2.Size = new System.Drawing.Size(125, 20);
            this.txtDocumento2.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(13, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "DOCUMENTO";
            // 
            // txtTipoPrograma2
            // 
            this.txtTipoPrograma2.Location = new System.Drawing.Point(508, 36);
            this.txtTipoPrograma2.Name = "txtTipoPrograma2";
            this.txtTipoPrograma2.Size = new System.Drawing.Size(160, 20);
            this.txtTipoPrograma2.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(505, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "TIPO PROGRAMA";
            // 
            // txtPrograma2
            // 
            this.txtPrograma2.Location = new System.Drawing.Point(337, 36);
            this.txtPrograma2.Name = "txtPrograma2";
            this.txtPrograma2.Size = new System.Drawing.Size(160, 20);
            this.txtPrograma2.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(334, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "PROGRAMA";
            // 
            // txtNombre2
            // 
            this.txtNombre2.Location = new System.Drawing.Point(162, 36);
            this.txtNombre2.Name = "txtNombre2";
            this.txtNombre2.Size = new System.Drawing.Size(160, 20);
            this.txtNombre2.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(159, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "ESTUDIANTE";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtPensum1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtTipoPrograma1);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtPrograma1);
            this.groupBox1.Controls.Add(this.txtDocumento1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtNombre1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(31, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(888, 72);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ESTUDIANTE 1";
            // 
            // txtPensum1
            // 
            this.txtPensum1.Location = new System.Drawing.Point(692, 39);
            this.txtPensum1.Name = "txtPensum1";
            this.txtPensum1.Size = new System.Drawing.Size(160, 20);
            this.txtPensum1.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(689, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "PENSUM";
            // 
            // txtTipoPrograma1
            // 
            this.txtTipoPrograma1.Location = new System.Drawing.Point(508, 39);
            this.txtTipoPrograma1.Name = "txtTipoPrograma1";
            this.txtTipoPrograma1.Size = new System.Drawing.Size(160, 20);
            this.txtTipoPrograma1.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(505, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "TIPO PROGRAMA";
            // 
            // txtPrograma1
            // 
            this.txtPrograma1.Location = new System.Drawing.Point(337, 39);
            this.txtPrograma1.Name = "txtPrograma1";
            this.txtPrograma1.Size = new System.Drawing.Size(160, 20);
            this.txtPrograma1.TabIndex = 16;
            // 
            // txtDocumento1
            // 
            this.txtDocumento1.Location = new System.Drawing.Point(16, 39);
            this.txtDocumento1.Name = "txtDocumento1";
            this.txtDocumento1.Size = new System.Drawing.Size(125, 20);
            this.txtDocumento1.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(334, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "PROGRAMA";
            // 
            // txtNombre1
            // 
            this.txtNombre1.Location = new System.Drawing.Point(162, 39);
            this.txtNombre1.Name = "txtNombre1";
            this.txtNombre1.Size = new System.Drawing.Size(160, 20);
            this.txtNombre1.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "DOCUMENTO";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(159, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "ESTUDIANTE";
            // 
            // btnPrototipo
            // 
            this.btnPrototipo.BackColor = System.Drawing.Color.Navy;
            this.btnPrototipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrototipo.ForeColor = System.Drawing.Color.White;
            this.btnPrototipo.Location = new System.Drawing.Point(12, 250);
            this.btnPrototipo.Name = "btnPrototipo";
            this.btnPrototipo.Size = new System.Drawing.Size(179, 62);
            this.btnPrototipo.TabIndex = 30;
            this.btnPrototipo.Text = "PROTOTIPO";
            this.btnPrototipo.UseVisualStyleBackColor = false;
            this.btnPrototipo.Click += new System.EventHandler(this.btnPrototipo_Click);
            // 
            // fPrototype
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 450);
            this.Controls.Add(this.btnPrototipo);
            this.Controls.Add(this.lblRespuesta);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "fPrototype";
            this.Text = "fPrototype";
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRespuesta;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtPensum3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtDocumento3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtTipoPrograma3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPrograma3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNombre3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtPensum2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtDocumento2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTipoPrograma2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPrograma2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNombre2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtPensum1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTipoPrograma1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtPrograma1;
        private System.Windows.Forms.TextBox txtDocumento1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNombre1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnPrototipo;
    }
}