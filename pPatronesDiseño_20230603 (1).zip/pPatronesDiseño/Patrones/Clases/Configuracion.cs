﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using pPatronesDiseño.Patrones.Creacionales.Abstract_Factory;

namespace pPatronesDiseño.Patrones.Clases
{
    public static class Configuracion
    {
        public static eBaseDatos baseDatos { get; set; }
    }
}
